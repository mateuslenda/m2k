declare module 'recoil' {
  export const RecoilRoot : any;
  export const atom : any;
  export const atomFamily : any;
  export const selector : any;
  export const useRecoilState : any;
  export const useRecoilValue : any;
}