import React from 'react';
import { 
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  TextField,
  DialogActions,
  Button 
} from '@material-ui/core';

const Auth = (props: any) => {
  return (
    <>
    </>
  );
}

export default Auth;