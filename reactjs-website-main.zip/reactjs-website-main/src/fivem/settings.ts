export default {
  ipMask: 'gtario.net',
  ip: '45.179.88.125',
  port: '30120' 
};
