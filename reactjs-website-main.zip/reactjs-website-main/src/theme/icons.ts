export class RioIcons {
  static discord : string = "\u0041";
  static facebook : string = "\u0042";
  static more : string = "\u0043";
  static twitter : string = "\u0044";
  static youtube : string = "\u0045";
}