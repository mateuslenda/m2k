# This is a view website for fivem
  This was my first React project
  
  - Material UI
  - Recoil JS
  - Dark theme, OS dark mode based
  - Responsive
  
![Image of Website](https://i.imgur.com/EcsJN7A.jpg)
![Image of Website](https://i.imgur.com/3bmWsxf.jpg)
